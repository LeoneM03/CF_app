const inputs = document.querySelectorAll(".input-field");
const toggle_btn = document.querySelectorAll(".toggle");
const main = document.querySelector("main");
const bullets = document.querySelectorAll(".bullets span");
const images = document.querySelectorAll(".image");

/* =============================== esto cambia nada mas el color de las barritas de los formularios donde escribes, ademas les coloca un estado de inactivo a activo cuando las usas es nomas un efecto visual ==================================*/
inputs.forEach((inp) => {
  inp.addEventListener("focus", () => {
    inp.classList.add("active");
  });
  inp.addEventListener("blur", () => {
    if (inp.value != "") return;
    inp.classList.remove("active");
  });
});


/* =============================== este es el control del carrusel por medio de las bullets, quice colocar un temporizador pero tenia muchos bugs asi que lo dejare para después recuérda me chavon ==================================*/
function moveSlider() {
  let index = this.dataset.value;

  let currentImage = document.querySelector(`.img-${index}`);
  images.forEach((img) => img.classList.remove("show"));
  currentImage.classList.add("show");

  const textSlider = document.querySelector(".text-group");
  textSlider.style.transform = `translateY(${-(index - 1) * 2.2}rem)`;

  bullets.forEach((bull) => bull.classList.remove("active"));
  this.classList.add("active");
}

bullets.forEach((bullet) => {
  bullet.addEventListener("click", moveSlider);
});


/* =============================== animacion de intro ==================================*/
const textParalax = document.querySelector(".text-paralax");
textParalax.style.top = "-100%";

window.addEventListener("load", function() {
  textParalax.style.top = "30%";
  textParalax.style.transition = "top 4s ease-out";
});



/* =============================== contador de caracteres ==================================*/

// Obtener el textarea y el elemento contador de caracteres
const textarea = document.getElementById("mensaje");
const contador = document.getElementById("contador-caracteres");

// Actualizar el contador de caracteres restantes
function actualizarContador() {
  const caracteresRestantes = 150 - textarea.value.length;
  contador.innerHTML = `${caracteresRestantes} / 150`;
}

// Llamar a la función de actualización del contador cada vez que se ingrese o se elimine texto en el textarea
textarea.addEventListener("input", actualizarContador);

