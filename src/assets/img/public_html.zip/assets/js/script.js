/* =============================== contador ==================================*/
  // Establece la fecha límite del contador
  const countDownDate = new Date("2023-07-29T15:00:00").getTime();

  // Actualiza el temporizador cada segundo
  const x = setInterval(() => {

    // Obtiene la fecha y hora actual
    const now = new Date().getTime();

    // Calcula la diferencia entre la fecha límite y la fecha actual
    const distance = countDownDate - now;

     // Calcula el tiempo restante en días, horas, minutos y segundos
  let months = Math.floor(distance / (1000 * 60 * 60 * 24 * 30));
  let days = Math.floor(distance / (1000 * 60 * 60 * 24));
  let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  let seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Calcula el número de días restantes en el mes actual
  const today = new Date();
  const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const daysRemaining = lastDayOfMonth - today.getDate();

  // Si quedan menos días que la cantidad total del mes actual, actualiza la variable de días
  if (days > daysRemaining) {
    days = daysRemaining;
  }
    // Actualiza el contenido de los elementos HTML
    document.getElementById("months").innerHTML = months;
    document.getElementById("days").innerHTML = days;
    document.getElementById("hours").innerHTML = hours;
    document.getElementById("minutes").innerHTML = minutes;
    document.getElementById("seconds").innerHTML = seconds;

    // Si la cuenta regresiva ha terminado, muestra un mensaje
    if (distance < 0) {
      clearInterval(x);
      document.getElementById("countdown").innerHTML = "EXPIRED";
    }
  }, 1000);

/* =============================== contenido oculto ==================================*/
$(document).ready(function() {
  // Ocultar todas las ventanas emergentes al inicio
  $('.popup').hide();

  // Variable global para almacenar la última ventana emergente abierta
  var lastPopup = null;
  
  // Agrega un evento de clic al body
  $('body').click(function(e) {
    // Verifica si el clic se realizó dentro de la ventana emergente
    if ($(e.target).closest('.popup').length === 0) {
      // Si el clic fue fuera de la ventana emergente, ocúltala
      $('.popup').hide();
      lastPopup = null;
    }
  });
  
  // Agrega la función de clic a cada tarjeta


  $('#tarjeta-galeria').click(function(e) {
    // Detiene la propagación del evento de clic en la tarjeta
    e.stopPropagation();
    if (lastPopup != null) {
      lastPopup.hide();
    }
    $('#popup-galeria').show();
    lastPopup = $('#popup-galeria');
  });
  
  $('#tarjeta-regalos').click(function(e) {
    // Detiene la propagación del evento de clic en la tarjeta
    e.stopPropagation();
    if (lastPopup != null) {
      lastPopup.hide();
    }
    $('#popup-regalos').show();
    lastPopup = $('#popup-regalos');
  });
  
  $('#tarjeta-mensaje').click(function(e) {
    // Detiene la propagación del evento de clic en la tarjeta
    e.stopPropagation();
    if (lastPopup != null) {
      lastPopup.hide();
    }
    $('#popup-mensaje').show();
    lastPopup = $('#popup-mensaje');
  });

  $('#tarjeta-vestimenta').click(function(e) {
    // Detiene la propagación del evento de clic en la tarjeta
    e.stopPropagation();
    if (lastPopup != null) {
      lastPopup.hide();
    }
    $('#popup-vestimenta').show();
    lastPopup = $('#popup-vestimenta');
  });
});


/* =============================== la cancion ==================================*/

var audio = document.getElementById("audio");
		var playButton = document.getElementById("playButton");
		var isPlaying = false;

		playButton.addEventListener("click", function() {
			if (isPlaying) {
				audio.pause();
				playButton.innerHTML = '<i class="fas fa-play"></i>';
			} else {
				audio.play();
				playButton.innerHTML = '<i class="fas fa-pause"></i>';
			}
			isPlaying = !isPlaying;
		});

  
  /* =============================== swipper iniciador ==================================*/
  var swiper = new Swiper(".mySwiper", {
    spaceBetween: 30,
    centeredSlides: true,
    autoplay: {
      delay: 3500,
      disableOnInteraction: false,
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });

  /* =============================== contador de caracteres ==================================*/

  function updateCount() {
    var textarea = document.getElementById("myTextarea");
    var count = document.getElementById("count");
    count.textContent = textarea.value.length;
    
    if (textarea.value.length > 200) {
      textarea.value = textarea.value.substr(0, 200);
      count.style.color = "red";
    } else {
      count.style.color = "black";
    }
  }