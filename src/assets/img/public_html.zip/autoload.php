<?php
    function autocargar_controladores($nombreClase){
        include 'controllers/'.$nombreClase.'.php';
    }

    spl_autoload_register('autocargar_controladores');

    //Para entenderlo mejor
    //https://cybmeta.com/como-registrar-y-utilizar-autoloaders-en-php
?>