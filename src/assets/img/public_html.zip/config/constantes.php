<?php
    define("url_base","https://manciaporrasds.com/");
    //define("url_base","http://localhost/laboda/");
    //define("url_base","https://manciaporrasds.com/boda-mancia-porras/");
    //define("url_base","https://laspruebasxd.000webhostapp.com/laboda/");
    define("controlador_default","LoginController");
    define('accion_default', 'loginVista');
    
?>