<?php
    class Conexion{

        public static function conectar(){
            //$db = new mysqli('us-east.connect.psdb.cloud','ubk0ygf9yyp2eeda5qgr','pscale_pw_2u2CYmVHa5AAn6gTnmauzf9W0BWUMQoprs6dkePe7Ox','bodadb');
            //$db = new mysqli('localhost','root','','bodadb');
            $db = new mysqli('beahhofjme4yf9rhh3nt-mysql.services.clever-cloud.com','uxdyptjm31ebekoh','vUxMbicYoCQI0BrjydbJ','beahhofjme4yf9rhh3nt');
            //consulta que permite resultados en castellano totalmente
            $db->query("SET NAMES 'utf8'");
            return $db;
        }
    }
?>