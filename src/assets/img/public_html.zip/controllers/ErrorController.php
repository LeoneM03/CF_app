<?php
    class ErrorController{
        public function elError(){
            echo "Esta pagina no existe man";
        }
    }
?>