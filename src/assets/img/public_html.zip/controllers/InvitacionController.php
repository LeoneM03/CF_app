<?php 
require_once "models/Invitados.php";
    class InvitacionController{
        public function invitacionVista(){
            require_once "views/layouts/invitacion.php";
        }

        public function laasistencia(){
            if(isset($_POST)){
                $asientos = $_POST['asientos'];
                $asistir = $_POST['asisencia'];
                $nombre =  $_POST['nombre'];

                $elinvitado = new Invitados();
                $elinvitado->setNombre($nombre);
                $elinvitado->setAusar($asientos);
                //$larespuesta = $elinvitado->insertar_asistencia();
                
                if($asistir == "si"){
                    $eldato = 1;
                    $elinvitado->setAsistencia($eldato); 
                    $larespuesta = $elinvitado->insertar_asistencia();
                    
                    if($larespuesta){
                        $invitadillo = $elinvitado->elinvitadillo();
                        $_SESSION['invitadillo']=$invitadillo;
                        $_SESSION['respuesta']=$asistir;
                        $_SESSION['plato']=false;
                        header("Location:".url_base.'Invitacion/invitacionVista');
                    }
                    else{
                        echo "error en consulta";
                    }
                    
                }
                else if($asistir == "no"){
                    $eldato = 2;
                    $elinvitado->setAsistencia($eldato); 
                    $larespuesta = $elinvitado->insertar_asistencia();
                    
                    if($larespuesta){
                        $_SESSION['respuesta']=2;
                        header("Location:".url_base.'Invitacion/invitacionVista');
                    }
                    else{
                        echo "error en consulta";
                    }
                }
                
            }
            else{
                echo "no hay nada en post";
            }
        }

        public function insertar_mensaje(){
            if(isset($_POST)){
                $elmensaje= isset($_POST['mensaje'])?$_POST['mensaje']:false;
                $elid= isset($_POST['elid'])?$_POST['elid']:false;

                $elinvitado = new Invitados();
                $elinvitado->setMensaje($elmensaje);
                $elinvitado->setId($elid);
                $resultado = $elinvitado->insertar_mensaje();
                if($resultado){
                    header("refresh:1; url=".url_base.'Invitacion/invitacionVista');
                }else{
                    echo "Error consulta";
                }

            }
            else{
                echo "no hay nada en el post";
            }
        }

        public function insertar_platos(){
            if(isset($_POST)){
                $pollo= isset($_POST['pollo'])?$_POST['pollo']:false;
                $carne= isset($_POST['carne'])?$_POST['carne']:false;
                $limite= isset($_POST['limite'])?$_POST['limite']:false;
                $elnombre= isset($_POST['nombre'])?$_POST['nombre']:false;

                $elinvitado = new Invitados();
                $elinvitado->setPollo($pollo);
                $elinvitado->setCarne($carne);
                $elinvitado->setNombre($elnombre);
                
                $total = $pollo + $carne ;
                if($total>$limite){
                    $mensaje = "Excedio. El total: ".$total.". El limite: ".$limite;
                    $_SESSION['el_limite']=true;
                }else{
                    $resultado = $elinvitado->insert_losplatos();
                    if($resultado){
                        $mensaje = "Plato insertado correctamente.";
                        $_SESSION['respuesta']="si";
                        $_SESSION["plato"]=true;
                        $_SESSION['fin']=true;
                        $laidentidad = $elinvitado->elinvitadillo();
                        $_SESSION['laid_final']=$laidentidad;
                        if(isset($_SESSION['el_limite'])){
                            unset($_SESSION['el_limite']);
                        }
                    }else{
                        $mensaje = "Error al insertar el plato.";
                    }
                }
                
                $_SESSION['mensaje'] = $mensaje;
                header("refresh:1; url=".url_base.'Invitacion/invitacionVista');
            }
            else{
                $mensaje = "No se recibieron datos del formulario.";
                $_SESSION['mensaje'] = $mensaje;
                header("refresh:3; url=".url_base.'Invitacion/invitacionVista');
            } 
        }

        public function elreset(){
            if(isset($_POST)){
                $nombre = isset($_POST['nombre'])?$_POST['nombre']:false;
                $elinvitado = new Invitados();
                $elinvitado->setNombre($nombre);
                $reseteo = $elinvitado->reseteo();
                if($reseteo){
                    $identidad = $elinvitado->elinvitadillo();
                    if($identidad){
                        $_SESSION['respuesta']=null;
                        $_SESSION['laid_final']=$identidad;
                        
                            unset($_SESSION['fin']);

                        
                        header("Location:".url_base.'Invitacion/invitacionVista');
                    }else{
                        echo 'algo en la consulta';
                    }
                }else{
                    echo 'no se reseteo';
                }      
            }
            else{
                echo 'no viene nada en post';
            }
            
        }

    }
?>