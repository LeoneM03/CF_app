<?php

require_once 'models/Invitados.php';

class LoginController{

    public function loginVista(){
        require_once 'views/layouts/login.php';
    }

    public function login(){
        if(isset($_POST)){
                
            $eltelefono =isset($_POST['telefono'])?$_POST['telefono']:false;
            $pais= isset($_POST['pais'])?$_POST['pais']:false;
            $elinvitado = new Invitados();

            $elinvitado->setTelefono($eltelefono);
            $elinvitado->setPais($pais);

            $identidad=$elinvitado->elLogin();

            if($identidad && is_object($identidad)){
                $_SESSION['laIdentidad']=$identidad;
                
                if($_SESSION['laIdentidad']->nombre == "Alejandra" && $_SESSION['laIdentidad']->apellidos == "Porras"){
                    header("Location:".url_base.'Portal/alejandraPortal');
                }
                else{
               $_SESSION['laid_final'] = $identidad;     
                    $_SESSION['respuesta']=$_SESSION['laIdentidad']->asistencia;
                    header("Location:".url_base.'Invitacion/invitacionVista');
                }    
            }
            else{
                
                $_SESSION['fallo_credencial']="error consulta";
                header("Location:".url_base);
                //echo 'Error en telefono o pais';
              
                
            }
        }
        else{
            $_SESSION['fallo']="error en post";
            //echo "no viene nada en el post";
        }
    }

   

}

?>