<?php 
require_once "models/Invitados.php";
    class PortalController{

        
        public function alejandraPortal(){
            require_once 'views/layouts/adminitrativo2.php';
        }
        
        public function listado_pdf(){
            require_once 'reports/listainvitados.php';
        }
        
        

        public  function registrar()
        {
            if($_POST){
                $elinvitado = new Invitados();

                $pais = isset($_POST['pais'])?$_POST['pais']:false;
                $telefono =  isset($_POST['telefono'])?$_POST['telefono']:false;
                $nombre =  isset($_POST['nombre'])?$_POST['nombre']:false;
                $apellidos =  isset($_POST['apellido'])?$_POST['apellido']:false;
                $asientos =  isset($_POST['asientos'])?$_POST['asientos']:false;
                $mesa = isset($_POST['mesa'])?$_POST['mesa']:false;

                $elinvitado->setPais($pais);
                $elinvitado->setTelefono($telefono);
                $elinvitado->setNombre($nombre);
                $elinvitado->setApellido($apellidos);
                $elinvitado->setAsientos($asientos);
                $elinvitado->setMesa($mesa);

                
                    $resultado = $elinvitado->registrar_invitados();

                    if($resultado){
                        if(isset($_SESSION['mesa_existe'])){
                            unset($_SESSION['mesa_existe']);
                        }
                        //header("Refresh: 1;URL=".url_base."Portal/alejandraPortal");
                        header("Location:".url_base.'Portal/alejandraPortal');
                    }
                    else{
                        echo "no se si inserto";
                    }      
                

                
            }
            else
            {
                echo "no viene nada en post";
            }
        }

        public function data_invitado()
        {
            if(isset($_GET)){
                $elid= isset($_GET['id'])?$_GET['id']:false;

                $elinvitado = new Invitados();
                $elinvitado->setId($elid);
                $invitado = $elinvitado->mostrar_invitado();
                $_SESSION['invitadillo'] = $invitado;
                header("Refresh:0; url=".url_base.'Portal/alejandraPortal');
                //echo "el telefono: ".$_SESSION['invitadillo']->id;
                //require_once 'views/layouts/editar.php';
                
                
            }
        }
        public function actualizar(){
            if($_POST){
                $id=isset($_POST['id'])? $_POST['id']:false;
                $nombre=isset($_POST['nombre'])? $_POST['nombre']:false;
                $apellido=isset($_POST['apellido'])? $_POST['apellido']:false;
                $pais=isset($_POST['pais'])? $_POST['pais']:false;
                $telefono=isset($_POST['telefono'])? $_POST['telefono']:false;
                $asientos=isset($_POST['asientos'])? $_POST['asientos']:false;
                $mesa=isset($_POST['mesa'])? $_POST['mesa']:false;

                $invitado = new Invitados();
                $invitado->setId($id);
                $invitado->setNombre($nombre);
                $invitado->setApellido($apellido);
                $invitado->setPais($pais);
                $invitado->setTelefono($telefono);
                $invitado->setAsientos($asientos);
                $invitado->setMesa($mesa);

                $resultado= $invitado->actualizar();

                if($resultado){
                    if(isset($_SESSION['invitadillo'])){
                        unset($_SESSION['invitadillo']);
                    }
                    header("Location:".url_base.'Portal/alejandraPortal');
                }else{
                    echo "Error consulta";
                }

            }else{
                echo "nada en el post";
            }
        }

        public  function eliminar()
        {
            if(isset($_GET)){
                
                $id =isset($_GET['id'])?$_GET['id']:false;
                
                $invitado = new Invitados();
                $invitado->setId($id);
                $resultado = $invitado->eliminar();

                if($resultado){
                    if(isset($_SESSION['invitadillo'])){
                        unset($_SESSION['invitadillo']);
                    }
                    header("Location:".url_base.'Portal/alejandraPortal');
                }else{
                    echo "no se elimino";
                }

            }else{
                echo "nada en el post";
            }
           
        }

        public  function cancelar()
        {
            if(isset($_SESSION['invitadillo'])){
                unset($_SESSION['invitadillo']);
            }
            header("Refresh:0; url=".url_base.'Portal/alejandraPortal');
        }

        public function logout(){
            if(isset($_SESSION['laIdentidad'])){
                unset($_SESSION['laIdentidad']);
            }if(isset($_SESSION['invitadillo'])){
                unset($_SESSION['invitadillo']);
            }
            
            header("Location:".url_base);
        }
    }
?>