<?php
    session_start();

    require_once 'autoload.php';    //cargar controlladores
    require_once 'config/db.php';   //conexion DB 
    require_once 'config/constantes.php'; //para URL,Controll,Action base
    require_once 'helpers/Utilidades.php';

    function mostrarError(){
        $error = new ErrorController();
        $error->elError();
    }


    if(isset($_GET['controller'])){
        $nombreControlador = $_GET['controller'].'Controller';
    }
    elseif(!isset($_GET['controller']) && !isset($_GET['action'])){
        $nombreControlador = controlador_default;
    }
    else{
        mostrarError();
        exit();
    }

    if(class_exists($nombreControlador)){
        $controlador = new $nombreControlador();

        if(isset($_GET['action']) && method_exists($controlador, $_GET['action'])){
            $accion = $_GET['action'];
            $controlador->$accion();
        }
        elseif(!isset($_GET['controller']) && !isset($_GET['action'])){
            $accion_pordefecto = accion_default;
            $controlador->$accion_pordefecto();
        }
        else{
            mostrarError();
        }
    }
    else{
        mostrarError();
    }

    
?>