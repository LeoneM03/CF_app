<?php
    class Invitados{
        private $id;
        private $nombre;
        private $apellido;
        private $asientos;
        private $mesa;
        private $asistencia;
        private $telefono;
        private $pais;
        private $mensaje;
        private $a_usar;
        private $pollo;
        private $carne;
        private $elreset;
        

        private $db;

        public function __construct()
        {
            $this->db=Conexion::conectar();    
        }

        //METODOS GET
        //GET
        public function getId()
        {
            return $this->id;
        }
        public function getNombre()
        {
            return $this->nombre;
        }
        public function getApellido()
        {
            return $this->apellido;
        }
        public function getAsientos()
        {
            return $this->asientos;
        }
        public function getMesa()
        {
            return $this->mesa;
        }
        public function getAsistencia()
        {
            return $this->asistencia;
        }
        public function getTelefono()
        {
            return $this->telefono;
        }
        public function getMensaje()
        {
            return $this->mensaje;
        }
        public function getPais()
        {
            return $this->pais;
        }
        public function getAusar()
        {
            return $this->a_usar;
        }
        public function getPollo()
        {
            return $this->pollo;
        }
        public function getCarne()
        {
            return $this->carne;
        }
        public function getElreset()
        {
            return $this->elreset;
        }

        //METODOS SET
        public function setId($id)
        {
            $this->id = $id;
        }
        public function setNombre($nombre)
        {
            $this->nombre = $nombre;
        }
        public function setAsientos($asientos)
        {
            $this->asientos = $asientos;
        }
        public function setMesa($mesa)
        {
            $this->mesa = $mesa;
        }
        public function setAsistencia($asistencia)
        {
            $this->asistencia = $asistencia;
        }
        public function setTelefono($telefono)
        {
            $this->telefono = $telefono;
        }
        public function setMensaje($mensaje)
        {
            $this->mensaje = $mensaje;
        }
        public function setPais($pais)
        {
            $this->pais = $pais;
        }
        public function setAusar($a_usar)
        {
            $this->a_usar = $a_usar;
        }
        public function setApellido($apellido)
        {
            $this->apellido = $apellido;
        }
        public function setPollo($pollo)
        {
            $this->pollo = $pollo;
        }
        public function setCarne($carne)
        {
            $this->carne = $carne;
        }
        public function setElreset($elreset)
        {
            $this->elreset = $elreset;
        }

        //METO PARA EL LOGIN
        
        public function elLogin(){
            $resultado = false;
            $eltelefono = $this->getTelefono();
            $pais = $this->getPais();

            //consulta
            $sql = "SELECT * FROM invitados WHERE telefono='$eltelefono' AND pais='$pais' ";
            $login_result = $this->db->query($sql);
        
            //validamos
            if($login_result){
                $elusuario = $login_result->fetch_object();

                $resultado = $elusuario;
               
            }

            return $resultado;
        }

        public function insertar_asistencia(){
            $resultado = false;
            $respuesta = $this->getAsistencia();
            $elnombre = $this->getNombre();
            $losasientos = $this->getAusar();

            //consulta
            $sql = "UPDATE invitados SET asistencia='$respuesta', a_usar ='$losasientos'  WHERE nombre='$elnombre'";
            $insertar = $this->db->query($sql);

            if($insertar){
                $resultado = true;
            }
            return $resultado;
        }

        public function elinvitadillo(){
            $resultado = false;
            $nombre=$this->getNombre();
            
            $sql = "SELECT * FROM invitados WHERE nombre = '$nombre'";
            $mostrar = $this->db->query($sql);

            if($mostrar){
                $elinvitado = $mostrar->fetch_object();
                $resultado = $elinvitado;
            }
            return $resultado;
        }

        public function reseteo(){
            $resultado = false;
            $elnombre = $this->getNombre();
            //consulta
            $sql = "UPDATE invitados SET  asistencia=NULL, a_usar =NULL, pollo=NULL, carne =NULL, elreset=1  WHERE nombre='$elnombre'";
            $insertar = $this->db->query($sql);

            if($insertar){
                $resultado = true;
            }
            return $resultado;
        }

        public function insert_losplatos(){
            $resultado = false;
            $pollo = $this->getPollo();
            $elnombre = $this->getNombre();
            $carne = $this->getCarne();

            //consulta
            $sql = "UPDATE invitados SET pollo='$pollo', carne ='$carne'  WHERE nombre='$elnombre'";
            $insertar = $this->db->query($sql);

            if($insertar){
                $resultado = true;
            }
            return $resultado;
        }

        public function insertar_mensaje(){
            $resultado = false;
            $elmensaje = $this->getMensaje();
            $elid = $this->getId();

            //consulta
            $sql = "UPDATE invitados SET mensaje='$elmensaje' WHERE id='$elid'";
            $insertar = $this->db->query($sql);

            if($insertar){
                $resultado = true;
            }
            return $resultado;
        }

        public function mostrar_invitados(){
            $resultado = false;
            
            $sql = "SELECT * FROM invitados WHERE nombre != 'Alejandra' AND apellidos !='Porras'";
            $mostrar = $this->db->query($sql);

            if($mostrar){
                
                $resultado = $mostrar;
            }
            return $resultado;
        }

        public function mostrar_invitado(){
            $resultado = false;
            $id=$this->getId();
            
            $sql = "SELECT * FROM invitados WHERE id = '$id'";
            $mostrar = $this->db->query($sql);

            if($mostrar){
                $elinvitado = $mostrar->fetch_object();
                $resultado = $elinvitado;
            }
            return $resultado;
        }

        public function registrar_invitados(){
            $resultado = false;
            $nombre = $this->getNombre();
            $apellidos = $this->getApellido();
            $mesa = $this->getMesa();
            $asientos = $this->getAsientos();
            $mensaje = $this->getMensaje();
            $telefono = $this->getTelefono();
            $pais = $this->getPais();


            $sql = "INSERT INTO invitados VALUES(NULL,'$nombre','$asientos','$mesa',NULL,Null,'$telefono','$pais',null,'$apellidos',null,null,null)";

            $insertar = $this->db->query($sql);

            if($insertar){
                $resultado = true;
            }

            return $resultado;

        }

        public function actualizar(){
            $resultado = false;
            $sql = "UPDATE invitados SET nombre='{$this->getNombre()}',apellidos='{$this->getApellido()}',asientos='{$this->getAsientos()}',mesa='{$this->getMesa()}',telefono='{$this->getTelefono()}',
            pais='{$this->getPais()}' WHERE id='{$this->getId()}'";
            
            $update = $this->db->query($sql);

            if($update){
                $resultado = true;
            }

            return $resultado;

        }

        public function eliminar(){
            $resultado = false;

            $sql = "DELETE FROM invitados WHERE id={$this->id}";
            $delete = $this->db->query($sql);

            if($delete){
                $resultado = true;
            }

            return $resultado;

        }

       public function invitados_reporte(){
            $resultado = false;

            $sql = "SELECT nombre, apellidos, mesa, a_usar,carne, pollo FROM invitados WHERE asistencia = 1;";
            $mostrar = $this->db->query($sql);

            if($mostrar){

                $resultado = $mostrar;
            }
            return $resultado;
        }

        public function total_invitados(){
            $resultado = false;

            $sql = "SELECT sum(a_usar) FROM invitados WHERE asistencia = 1;";
            $mostrar = $this->db->query($sql);

            if($mostrar){

                $resultado = $mostrar;
            }
            return $resultado;
        }

        public function pollos(){
            $resultado = false;

            $sql = "SELECT  sum(pollo) FROM invitados WHERE asistencia = 1;";
            $mostrar = $this->db->query($sql);

            if($mostrar){

                $resultado = $mostrar;
            }
            return $resultado;
        }

        public function carnes(){
            $resultado = false;

            $sql = "SELECT  sum(carne) FROM invitados WHERE asistencia = 1;";
            $mostrar = $this->db->query($sql);

            if($mostrar){

                $resultado = $mostrar;
            }
            return $resultado;
        }
    }


?>