<?php
    ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preload" href="<?=url_base?>assets/css/admin.css" as="style">
    <link rel="shortcut icon" href="<?=url_base?>assets/img/monograma-EA.png" />
    <link rel="stylesheet" href="<?=url_base?>assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Lista Invitados</title>
</head>
<body class="admin">
<section class="dashasist">

<h1>
    Listado de invitados
</h1>
<table border="1">
  <thead>
    <tr>
      <th>Invitado</th>
      <th>Mesa</th>
      <th>N° Personas</th>
      <th>Carne</th>
      <th>Pollo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <?php 
      require_once "models/Invitados.php";
      $invitados = new Invitados();

      $los_invitados = $invitados->invitados_reporte();
      $total_invi = $invitados->total_invitados();
      $lascarnes = $invitados->carnes();
      $lospollos = $invitados->pollos();

      $mostrar_total=mysqli_fetch_array($total_invi);
      $mostrar_carnes=mysqli_fetch_array($lascarnes);
      $mostrar_pollos=mysqli_fetch_array($lospollos);

      while($mostrar=mysqli_fetch_array($los_invitados)){

    ?>
    <tr>
      <td><?php echo $mostrar['nombre'] ?> <?php echo $mostrar['apellidos'] ?></td>
      <td><?php echo $mostrar['mesa'] ?></td>
      <td><?php echo $mostrar['a_usar'] ?></td>
      <td><?php echo $mostrar['carne'] ?></td>
      <td><?php echo $mostrar['pollo'] ?></td>
    </tr>
    <?php
      }
    ?>
    <tr>
      <td> <b>TOTAL</b> </td>
      <td></td>
      <td> <b><?php echo $mostrar_total[0] ?></b></td>
      <td><b><?php echo $mostrar_carnes[0] ?></b></td>
      <td><b><?php echo $mostrar_pollos[0] ?></b></td>
    </tr>
  </tbody>
  </table>

</section>
</body>
</html>
<?php
    $html = ob_get_clean();
?>

<?php
    require_once 'assets/pdf/dompdf/autoload.inc.php';

    use Dompdf\Dompdf;

    $dompdf = new Dompdf();

    $configuraciones=  $dompdf->getOptions();
    $configuraciones->set(array('isRemoteEnable' =>true));

    $dompdf->setOptions($configuraciones);
    
    $dompdf->loadHtml($html);

    $dompdf->setPaper("letter");
    //$dompdf->setPaper('A4','landscape');

    $dompdf->render();
    $dompdf->stream("archivo.pdf",array("Attachment"=>false));

?>



