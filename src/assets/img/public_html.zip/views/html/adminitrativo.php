<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preload" href="<?=url_base?>assets/CSS/admin.css" as="style">
    <link rel="shortcut icon" href="<?=url_base?>assets/img/monograma-EA.png" />
    <link rel="stylesheet" href="<?=url_base?>assets/CSS/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Home</title>
</head>


<body class="admin">

    <header>
        <nav>
          <h1>Para la patrona</h1>
          <ul>
            <h2>
                Bienvenida <span> Alejandra Porras</span> 
            </h2>
            <li>
              <a href="<?=url_base?>Portal/logout"> Cerrar Sesión </a>
            </li>
          </ul>
        </nav>
      </header>

      

    <section class="dashasist">

        <h1>
            Listado de invitados
        </h1>
        <table>
          <thead>
            <tr>
              <th>Código area</th>
              <th>Teléfono</th>
              <th>Nombre</th>
              <th>Asientos</th>
              <th>Asientos a usar</th>
              <th>Mesa</th>
              <th>Confirmación</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr>
            <?php 
              require_once "models/invitados.php";
              $invitados = new Invitados();

              $resultado = $invitados->mostrar_invitados();
              while($mostrar=mysqli_fetch_array($resultado)){

            ?>
            <tr>

              <?php 
                $elpais = $mostrar['pais'];
                switch($elpais){
                    case "us":
                        echo '<td>+1</td>';
                    break;

                    case "sv":
                        echo '<td>+503</td>';
                    break;

                    case "mx":
                        echo '<td>+52</td>';
                    break;

                    case "es":
                        echo '<td>+54</td>';
                    break;   

                }
              
              ?>
              <td><?php echo $mostrar['telefono'] ?></td>
              <td><?php echo $mostrar['nombre'] ?></td>
              <td><?php echo $mostrar['asientos'] ?></td>

              <?php if($mostrar['a_usar']!=null):?>
                <td><?php echo $mostrar['a_usar'] ?></td>
              <?php else: ?>
                <td>Sin confirmar</td>
              <?php endif; ?>

              <td><?php echo $mostrar['mesa'] ?></td>

              <?php if($mostrar['asistencia'] == 1):?>
                <td>SI</td>
              <?php elseif($mostrar['asistencia'] == 2): ?>
                <td>no</td>
              <?php else: ?>
                <td>Sin confirmar</td>
              <?php endif; ?>


              <td class="actions">

                <div class="boton-modal edit ">
                  <a href="<?=url_base?>Portal/data_invitado&id=<?=$mostrar['id']?>"><label for="">Editar</label></a>
                
                   <!-- <label for="edit">Editar</label> <a href="" for="edit">Editar</a> -->
                </div>
                
                <div class="boton-modal delete " >
                  <label for="delete">Borrar</label>
                </div>
               

                <!-- 
                    <button class="edit">Editar</button>
                <button class="delete">Borrar</button>
                 -->
                
              </td>
            </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
          <div class="boton">
            <input type="submit" value="Imprimir listado" class="btn" />
          </div>


         

          <!-- modal para edit -->
          <input type="checkbox" id="edit">
          <div class="container-modal-edit">
           
  
            <div class="content-modal"> 

              <div class="formulario">
                <h1>
                    Editar invitado
                </h1>
        
                    <form class="user" action="<?=url_base?>Portal/actualizar" method="post">
                        <div class="actual-form">
    
    
                        
                           <!-- casilla de formulario -->
                    <div class="input-wrap">
                      <select class="input-field" name="pais" required>
                        <option value="">--Seleccione un país--</option>
                        <option value="us">Estados Unidos (+1)</option>
                        <option value="sv">El Salvador (+503)</option>
                        <option value="mx">México (+52)</option>
                        <option value="es">España (+34)</option>
                      </select>
                    
                    </div>
              
                           <!-- casilla de formulario -->
                           <div class="input-wrap">
                            <input
                              type="number"
                              minlength="4"
                              class="input-field"
                              autocomplete="off"
                              name="telefono"
                              placeholder="Telefono"
                              value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->telefono : ''; ?>"
                              required
                            />
                            
                          </div>
                            <!-- casilla de formulario -->
                            <div class="input-wrap">
                              <input
                                type="text"
                                minlength="4"
                                class="input-field"
                                autocomplete="off"
                                name="nombre"
                                placeholder="Nombre Invitado"
                                value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->nombre : ''; ?>"
                                required
                              />
                              
                            </div>
                              <!-- casilla de formulario -->
                              <div class="input-wrap">
                                <input
                                  type="number"
                                  minlength="1"
                                  class="input-field"
                                  autocomplete="off"
                                  placeholder="Asientos disponibles"
                                  name="asientos"
                                  value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->asientos : ''; ?>"
                                  required
                                />
                                
                              </div>
                                <!-- casilla de formulario -->
                                <div class="input-wrap">
                                  <select class="input-field" name="mesa" required>
                                    <option value="">--Seleccione una mesa--</option>
                                    <option value="1">Mesa 1</option>
                                    <option value="2">Mesa 2</option>
                                    <option value="3">Mesa 3</option>
                                    <option value="4">Mesa 4</option>
                                    <option value="5">Mesa 5</option>
                                    <option value="6">Mesa 6</option>
                                    <option value="7">Mesa 7</option>
                                    <option value="8">Mesa 8</option>
                                    <option value="9">Mesa 9</option>
                                    <option value="10">Mesa 10</option>
                                    <option value="11">Mesa 11</option>
                                    <option value="12">Mesa 12</option>
                                    <option value="13">Mesa 13</option>
                                    <option value="14">Mesa 14</option>
                                    <option value="15">Mesa 15</option>
                                    <option value="16">Mesa 16</option>
                                    <option value="17">Mesa 17</option>
                                    <option value="18">Mesa 18</option>
                                    <option value="19">Mesa 19</option>
                                  </select>
                                
                                </div>
                                <!-- casilla de formulario -->
            
                          </div>
        
                           <!-- enserio? lee ahi dice btn osea boton :v thing mark thing -->
                         
        
                    </form>
                    
            </div>

            <div class="btn-modal">
              <input type="submit" class="btn-guardar-modal" value="Guardar"/>
              <label for="edit" class="btn-modal-label" style="margin-left: 15px;"> Descartar </label>
            </div>
            </div>

          </div>

          <!-- modal ends -->
          <input type="checkbox" id="delete">
          <div class="container-modal-delete">
            <div class="content-modal">


              <h2>¿ahuevo queres borrar a este maje?</h2> 

              <div class="btn-modal">
                <button class="btn-edit-modal" for="simon">De una</button>
                <label class="btn-modal-label" style="margin-left: 15px;" for="delete"> No perame</label>
              </div>


            </div>
          </div>

          <!-- modal eliminar -->

          <!-- modal end -->
    </section>


    <section class="invitados-agree">

        <div class="formulario">
            
            <?php if(isset($_SESSION['invitadillo'])):?>
              <h1>Editar Invitado</h1>
              <?php //$url_action = url_base."Portal/save&id=".$pro->id; 
              $url_action = url_base."Portal/actualizar";?>
              
            <?php else:?>
              <h1>
                Agregar invitados
              </h1>
              <?php $url_action = url_base."Portal/registrar"; ?>
            <?php endif; ?>
              
                <form class="user" action="<?=$url_action?>" method="post">
                    <div class="actual-form">


                    
                       <!-- casilla de formulario -->
                    <div class="input-wrap">
                      <select class="input-field" name="pais" required>
                        <option value="">--Seleccione un país--</option>
                        <option value="us">Estados Unidos (+1)</option>
                        <option value="sv">El Salvador (+503)</option>
                        <option value="mx">México (+52)</option>
                        <option value="es">España (+34)</option>
                      </select>
                    
                    </div>

                          <input type="hidden" name="id" value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->id : ''; ?>">
              
                           <!-- casilla de formulario -->
                           <div class="input-wrap">
                            <input
                              type="number"
                              minlength="4"
                              class="input-field"
                              autocomplete="off"
                              name="telefono"
                              placeholder="Telefono"
                              value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->telefono : ''; ?>"
                              
                              required
                            />
                            
                          </div>
                            <!-- casilla de formulario -->
                            <div class="input-wrap">
                              <input
                                type="text"
                                minlength="4"
                                class="input-field"
                                autocomplete="off"
                                name="nombre"
                                placeholder="Nombre Invitado"
                                value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->nombre : ''; ?>"
                                required
                              />
                              
                            </div>
                              <!-- casilla de formulario -->
                              <div class="input-wrap">
                                <input
                                  type="number"
                                  minlength="1"
                                  class="input-field"
                                  autocomplete="off"
                                  placeholder="Asientos disponibles"
                                  name="asientos"
                                  value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->asientos : ''; ?>"
                                  required
                                />
                              </div>
                            <!-- casilla de formulario -->
                            <div class="input-wrap">
                              <select class="input-field" name="mesa" required>
                                <option value="">--Seleccione una mesa--</option>
                                <option value="1">Mesa 1</option>
                                <option value="2">Mesa 2</option>
                                <option value="3">Mesa 3</option>
                                <option value="4">Mesa 4</option>
                                <option value="5">Mesa 5</option>
                                <option value="6">Mesa 6</option>
                                <option value="7">Mesa 7</option>
                                <option value="8">Mesa 8</option>
                                <option value="9">Mesa 9</option>
                                <option value="10">Mesa 10</option>
                                <option value="11">Mesa 11</option>
                                <option value="12">Mesa 12</option>
                                <option value="13">Mesa 13</option>
                                <option value="14">Mesa 14</option>
                                <option value="15">Mesa 15</option>
                                <option value="16">Mesa 16</option>
                                <option value="17">Mesa 17</option>
                                <option value="18">Mesa 18</option>
                                <option value="19">Mesa 19</option>

                              </select>
                            
                            </div>
                            <!-- casilla de formulario -->
        
                      </div>
                      <?php if(isset($_SESSION['invitadillo'])):?>
<!--******************************** LOS BOTONES *****************************************************************************************************************-->
                          <!-- BOTON ACTUALIZAR -->
                          <div class="boton">                            
                            <input type="submit" value="Actualizar" class="btn" />                         
                          </div>       
                          <!-- BOTON ELIMINAR -->
                          <div class="boton">                            
                            <input type="submit" value="Eliminar" class="btn" />                         
                          </div>   
                          
                        <?php else:?> 
                          <!-- BOTON AGREGAR  este asi esta bien NO LO TOQUEEEEES-->
                          <div class="boton">
                            <input type="submit" value="Agregar" class="btn" />
                          </div>
                        <?php endif?>
    
                </form>
                <?php if(isset($_SESSION['invitadillo'])):?>
                <form action="<?=url_base?>Portal/cancelar">
                <!-- BOTON CANCELAR -->
                  <div class="boton">            
                      <input type="submit" value="Cancelar" class="btn" />
                  </div>
                </form>
                <?php endif?>
<!--******************************** LOS BOTONES *****************************************************************************************************************-->                

                 
        </div>


        

    </section>
        <script src="<?=url_base?>assets/JS/script.js"></script>   
</body>


</html>


