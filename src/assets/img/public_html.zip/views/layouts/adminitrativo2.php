<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preload" href="<?=url_base?>assets/css/admin.css" as="style">
    <link rel="shortcut icon" href="<?=url_base?>assets/img/monograma-EA.png" />
    <link rel="stylesheet" href="<?=url_base?>assets/css/admin.css">
     <!-- Boxicons CSS -->
     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
      <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <SCRIPT LANGUAGE="JavaScript">
          history.forward()
    </SCRIPT>
    <title>Home</title>
</head>


<body class="admin">

    <header>
        <nav>
          <h1>Para la patrona</h1>
          <ul>
            <h2>
                Bienvenida <span> Alejandra Porras</span> 
            </h2>
            <li>
              <a href="<?=url_base?>Portal/logout"> Cerrar Sesión </a>
            </li>
          </ul>
        </nav>
      </header>

      

    <section class="dashasist">

        <h1>
            Listado de invitados
        </h1>
        <table>
          <thead>
            <tr>
              <th>Código area</th>
              <th>Teléfono</th>
              <th>Nombre</th>
              <th>Asientos</th>
              <th>Asientos a usar</th>
              <th>Mesa</th>
              <th>Confirmación</th>
              <th>Pollo</th>
              <th>Carne</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr>
            <?php 
              require_once "models/Invitados.php";
              $invitados = new Invitados();

              $resultado = $invitados->mostrar_invitados();
              while($mostrar=mysqli_fetch_array($resultado)){

            ?>
            <tr>

              <?php 
                $elpais = $mostrar['pais'];
                switch($elpais){
                    case "us":
                        echo '<td>+1</td>';
                    break;

                    case "sv":
                        echo '<td>+503</td>';
                    break;

                    case "mx":
                        echo '<td>+52</td>';
                    break;

                    case "es":
                        echo '<td>+54</td>';
                    break;   
                    
                     case "ca":
                        echo '<td>+1</td>';
                    break;  
                    
                    case "guat":
                        echo '<td>+502</td>';
                    break;  

                }
              
              ?>
              <td><?php echo $mostrar['telefono'] ?></td>
              <td><?php echo $mostrar['nombre'] ?> <?php echo $mostrar['apellidos'] ?></td>
              <td><?php echo $mostrar['asientos'] ?></td>

              <?php if($mostrar['a_usar']!=null):?>
                <td><?php echo $mostrar['a_usar'] ?></td>
              <?php else: ?>
                <td>Sin confirmar</td>
              <?php endif; ?>

              <td><?php echo $mostrar['mesa'] ?></td>

              <?php if($mostrar['asistencia'] == 1):?>
                <td>SI</td>
              <?php elseif($mostrar['asistencia'] == 2): ?>
                <td>no</td>
              <?php else: ?>
                <td>Sin confirmar</td>
              <?php endif; ?>
              <td><?php echo $mostrar['pollo'] ?></td>
              <td><?php echo $mostrar['carne'] ?></td>

              <td class="actions">

                <div class="boton-modal edit ">
                  <a href="<?=url_base?>Portal/data_invitado&id=<?=$mostrar['id']?>"><label for="">Editar</label></a>
                
                   <!-- <label for="edit">Editar</label> <a href="" for="edit">Editar</a> -->
                </div>              

                <!-- 
                    <button class="edit">Editar</button>
                <button class="delete">Borrar</button>
                 -->
                
              </td>
            </tr>
            <?php
              }
            ?>
          </tbody>
          </table>
          <form action="<?=url_base?>Portal/listado_pdf">
          <div class="boton">
              <input type="submit" value="Imprimir listado" class="btn" />
            </div>
          </form>
            


         

          

          <!-- modal eliminar -->

          <!-- modal end -->
    </section>


    <section class="invitados-agree">

        <div class="formulario">
            
            <?php if(isset($_SESSION['invitadillo'])):?>
              <h1>Editar Invitado</h1>
              <?php //$url_action = url_base."Portal/save&id=".$pro->id; 
              $url_action = url_base."Portal/actualizar";?>
              
            <?php else:?>
              <h1>
                Agregar invitados
              </h1>
              <?php $url_action = url_base."Portal/registrar"; ?>
            <?php endif; ?>
              
                <form class="user" action="<?=$url_action?>" method="post">
                    <div class="actual-form">


                    
                       <!-- casilla de formulario -->
                    <div class="input-wrap">
                      <select class="input-field" name="pais" required>
                        <option value="">--Seleccione un país--</option>
                        <option value="us">Estados Unidos (+1)</option>
                        <option value="sv">El Salvador (+503)</option>
                          <option value="guat">Guatemala (+502)</option>
                        <option value="mx">México (+52)</option>
                        <option value="es">España (+34)</option>
                         <option value="ca">Canada (+1)</option>
                         
                      </select>
                    
                    </div>

                          <input type="hidden" name="id" value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->id : ''; ?>">
              
                           <!-- casilla de formulario -->
                           <div class="input-wrap">
                            <input
                              type="number"
                              minlength="4"
                              class="input-field"
                              autocomplete="off"
                              name="telefono"
                              placeholder="Telefono"
                              value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->telefono : ''; ?>"
                              
                              required
                            />
                            
                          </div>
                            <!-- casilla de formulario -->
                            <div class="input-wrap">
                              <input
                                type="text"
                                minlength="4"
                                class="input-field"
                                autocomplete="off"
                                name="nombre"
                                placeholder="Nombre Invitado"
                                value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->nombre : ''; ?>"
                                required
                              />
                              
                            </div>
                            <div class="input-wrap">
                              <input
                                type="text"
                                minlength="4"
                                class="input-field"
                                autocomplete="off"
                                name="apellido"
                                placeholder="Apellido Invitado"
                                value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->apellidos : ''; ?>"
                                required
                              />
                              
                            </div>
                              <!-- casilla de formulario -->
                              <div class="input-wrap">
                                <input
                                  type="number"
                                  minlength="1"
                                  class="input-field"
                                  autocomplete="off"
                                  placeholder="Asientos disponibles"
                                  name="asientos"
                                  value="<?=isset($_SESSION['invitadillo'] )? $_SESSION['invitadillo']->asientos : ''; ?>"
                                  required
                                />
                              </div>
                            <!-- casilla de formulario -->
                            <div class="input-wrap">
                              <select class="input-field" name="mesa">
                                <option value="">--Seleccione una mesa--</option>
                                <option value="1">Mesa 1</option>
                                <option value="2">Mesa 2</option>
                                <option value="3">Mesa 3</option>
                                <option value="4">Mesa 4</option>
                                <option value="5">Mesa 5</option>
                                <option value="6">Mesa 6</option>
                                <option value="7">Mesa 7</option>
                                <option value="8">Mesa 8</option>
                                <option value="9">Mesa 9</option>
                                <option value="10">Mesa 10</option>
                                <option value="11">Mesa 11</option>
                                <option value="12">Mesa 12</option>
                                <option value="13">Mesa 13</option>
                                <option value="14">Mesa 14</option>
                                <option value="15">Mesa 15</option>
                                <option value="16">Mesa 16</option>
                              

                              </select>
                            
                            </div>
                            <!-- casilla de formulario -->
        
                      </div>
                      <?php if(isset($_SESSION['invitadillo'])):?>
<!--******************************** LOS BOTONES *****************************************************************************************************************-->
                          <!-- BOTON ACTUALIZAR -->

                          <div class="botones-formulario">

                          <style>
                            .botones-formulario{
                              display: flex;
                              align-items: center;
                              
                            }
                            .botones-formulario .boton{
                              margin-right: 10px;
                            }
                          </style>


                          <div class="boton">                            
                            <input type="submit" value="Actualizar" class="btn" />                         
                          </div>       
                          <!-- BOTON ELIMINAR -->
                           
                          
                        <?php else:?> 
                          <!-- BOTON AGREGAR  este asi esta bien NO LO TOQUEEEEES-->
                          <div class="boton">
                            <input type="submit" value="Agregar" class="btn" />
                          </div>
                        <?php endif?>


                          </div>  
                         
    
                </form>
                
                <?php if(isset($_SESSION['invitadillo'])):?>
                <form action="<?=url_base?>Portal/eliminar&id=<?=$_SESSION['invitadillo']->id?>">
                <input type="hidden" name="id" value="">
                <!-- BOTON ELIMINAR -->
                <div class="boton">                            
                            <input type="submit" value="Eliminar" class="btn" />                         
                          </div> 
                </form>
                <?php endif?>

                <?php if(isset($_SESSION['invitadillo'])):?>
                <form action="<?=url_base?>Portal/cancelar">
                <!-- BOTON CANCELAR -->
                  <div class="boton">            
                      <input type="submit" value="Cancelar" class="btn" />
                  </div>
                </form>
                <?php endif?>
<!--******************************** LOS BOTONES *****************************************************************************************************************-->                

                 
        </div>


        

    </section>



    <section class="mensajes-novios">
  
 
  
  <div class="testimonial mySwiper">
    <div class="testi-content swiper-wrapper">
      
        <?php 
          require_once "models/Invitados.php";
          $invitados = new Invitados();

          $resultado = $invitados->mostrar_invitados();
          while($mostrar=mysqli_fetch_array($resultado)){

            if($mostrar['mensaje']!=null){     
        ?>
        <!-- EL mensajes -->
        <div class="slide swiper-slide">
         

          <div class="slide-content">
            <p id="comentario">
            <?= $mostrar['mensaje']?>
              
            </p>
            <i class="bx bxs-quote-alt-left"></i>
    
            <div class="testi-detalles">
            
              <span class="nombre"><?= $mostrar['nombre']?></span>
              <span class="apellido"><?= $mostrar['apellidos']?></span>


            </div>
          </div>
          


        </div>
        <!-- EL mensajes -->
        <?php }?>
      <?php }?>
      
      


    </div>
    <div class="swiper-pagination"></div>
  </div>


 
</section>

        <script src="<?=url_base?>assets/js/script.js"></script>   
        <script src="https://cdn.jsdelivr.net/npm/swiper@9.1.1/swiper-bundle.min.js"></script>
</body>


</html>


