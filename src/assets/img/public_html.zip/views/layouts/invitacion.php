<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    
    <meta http-equiv="Expires" content="0">
    <SCRIPT LANGUAGE="JavaScript">
          history.forward()
    </SCRIPT>
    <title>¡Nos Casamos!</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <link rel="stylesheet" href="<?=url_base?>/assets/css/home.css">
    <link rel="shortcut icon" href="<?=url_base?>assets/img/monograma-EA.png" />
    <!-- Boxicons CSS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
      <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />

  </head>
<body>

    

<main>

  
      <!-- banner inicial -->       
<section class="home" id="home" class="fade-in">

    <div class="banner"> 
     <img class="fondo" src="<?=url_base?>assets/img/banners/banner-inicio.png" alt="" id="fondo">
    </div>
    
    <div class="content">
      <div class="content-title">
        <h2>¡NOS CASAMOS!</h2>
      </div>
      <div class="content-content">
        <div class="name-box" id="enrie">
          <h1>Enrique</h1>
          <p>Mancía</p>
        </div>
    
        <div class="emblema">
          <img src="<?=url_base?>assets/img/monograma-EA.png" alt="" id="emble">
        </div>
    
        <div class="name-box" id="ale">
          <h1>Alejandra</h1>
          <p>Porras</p>
        </div>
      </div>  
      <div class="saludo">
        <h2>Con gran emoción, queremos <br>
          que seas parte de</h2>
          <h1>NUESTRA BODA</h1>
      </div>
    </div>

</section>
        <!-- banner inicial end -->

  <!-- temporizador start -->
<section class="temporizador">
<h2>Sólo faltan...</h2>
<div class="countdown">
  <div>
    <span class="number" id="months"></span>
    <span class="subtitle">Meses</span>
  </div>
  <div>
    <span class="number" id="days"></span>
    <span class="subtitle">Dias</span>
  </div>
  <div>
    <span class="number" id="hours"></span>
    <span class="subtitle">Horas</span>
  </div>
  <div>
    <span class="number" id="minutes"></span>
    <span class="subtitle">Minutos</span>
  </div>
  <div style="display: none;">
    <span class="number" id="seconds"></span>
    <span class="subtitle">Seg</span>
  </div>
</div>
<h2>para el gran día</h2>
<div class="fecha-content">

  <h2>Sábado<span>29</span>Julio</h2>

</div>
</section>
  <!-- temporizador ends -->

<div class="separador"></div>

       <!-- ubicacion de ceremonia -->
<section class="ubicacion">

  <div class="ubicacion-img">
    <img src="<?=url_base?>assets/img/iconos/icon-igle.png" alt="">
  </div>

  <div class="ubicacion-content">

    <h2>
      Acompáñanos a la ceremonia religiosa a celebrarse en:
    </h2>
    
    <div class="ubicacion-titulo">
      <h1>parroquia</h1>
      <h1>"santa elena"</h1>
    
    </div>

    <div class="ubicacion-fecha">
      <h2>3:00 <span>P.M.</span></h2>
    </div>

    <div class="ubicacion-parrafo">
    <h2>
    "El matrimonio no solo es unir dos vidas, sino dos familias y dos corazones para siempre”.
    </h2>
    <h2>San Agustín</h2>
    </div>
  

    <div class="btn-ubicacion">
      <a href="https://waze.com/ul/hd42t8xyve" target="_blank" class="btn">Haz click para la ubicación</a>
    </div>
  </div>


</section>
        <!-- ubicacion de ceremonia end -->

<div class="separador"></div>

       <!-- ubicacion de fiesta -->
<section class="ubicacion">

        <div class="ubicacion-img">
          <img src="<?=url_base?>assets/img/iconos/icon-copa.png" alt="">
        </div>
      
        <div class="ubicacion-content">

        <div class="ubicacion-parrafo">
        <h2>
            Posteriormente una recepción en:
          </h2>
        </div>
         
          
          <div class="ubicacion-titulo">
            <h1>museo marte</h1>
          </div>
      
          <div class="ubicacion-fecha">
            <h2>6:00 <span>P.M.</span></h2>
          </div>
          

          <div class="ubicacion-parrafo">
          <h2>
            ¡No te lo puedes perder!
          </h2>
          </div>
         
          
          <div class="btn-ubicacion">
            <a href="https://waze.com/ul/hd42tck8mn" target="_blank" class="btn">Haz click para la ubicación</a>
          </div>
           
        </div>
</section>
        <!-- ubicacion de fiesta -->

        <!-- banner medio -->
<div class="home">
  <div class="banner-2">
    <img src="<?=url_base?>assets/img/banners/banner-medio.png" alt="">
  </div>
</div>
        <!-- banner medio end -->


        <!-- asistencia start -->
<?php if(is_null($_SESSION['respuesta'])): ?>
    <section class="asistencia">
        <div class="asistencia-title">
            <h2>Lo tenemos todo preparado, <br> pero nos falta lo más importante
                <br>tú presencia para disfrutar entre adultos.</h2>
        </div>
        <!-- ************************************************* LA ASISTENCIA ***********************************************************-->
        <form action="<?=url_base?>Invitacion/laasistencia" method="post">
            <input type="hidden" name="nombre" value="<?=$_SESSION['laIdentidad']->nombre?>">
            <div class="form-cintillo">
                <h2>¿Nos acompañarás?</h2>
            </div>

            <div class="form-group">
                <div class="radio">
                    <div class="radio1">
                        <input type="radio" id="si" name="asisencia" value="si">
                        <label for="si">Sí</label>
                    </div>
                    <div class="radio2">
                        <input type="radio" id="no" name="asisencia" value="no">
                        <label for="no">No</label>
                    </div>
                </div>

                <?php if(isset($_SESSION['laIdentidad'])): ?>
                    <div class="asientos">
                        <h2>Hemos reservado para ud.(s) <span><?=$_SESSION['laIdentidad']->asientos ?></span> asiento(s)</h2>
                    </div>

                    <div class="mesas">
                        <h2>Tu mesa asignada es la: <br><br><span> n°. <?=$_SESSION['laIdentidad']->mesa ?> </span></h2>
                    </div>

                    <?php if($_SESSION['laIdentidad']->asientos > 1): ?>
                        <div class="confirmar-asientos">
                            <label for="confi-asient">Confirma cuántas personas asistirán:</label>
                            <select id="nAsient" name="asientos">
                                <?php for($i=0; $i<= $_SESSION['laIdentidad']->asientos; $i++){ ?>
                                    <option value="<?=$i?>"><?=$i?></option>
                                <?php }?>
                            </select>
                        </div>
                    <?php elseif($_SESSION['laIdentidad']->asientos == 1): ?>
                        <input type="hidden" name="asientos" value="1">
                    <?php endif; ?>

                <?php else: ?>
                    <div class="mesas">
                        <h1>No asignado</h1>
                    </div>
                <?php endif; ?>

                <div class="botones">
                    <button type="submit" class="btn">Enviar</button>
                </div>
            </div>
        </form>
    </section>



  <?php elseif($_SESSION["respuesta"]=="si" && $_SESSION["plato"]==false): ?>
    <section class="asistencia">
      <?php if(isset($_SESSION["el_limite"])): ?>
        <div class="asistencia-confirm">
          <h2>Excedió el limite de platos</h2>
        </div>

      <?php else: ?>
        <div class="asistencia-confirm">
          <h2 style="font-size: 3rem; display: none;">Su cena</h2>
        </div>
      <?php endif;?>

      <div class="carta-cena">
      <form  action="<?=url_base?>Invitacion/insertar_platos" method="post">
       
       <h2 class="platos-title">
         ¿Qué prefieres cenar?
       </h2>
       <h2 class="platos-title">
         Su total de platos limite es <span><?=$_SESSION['invitadillo']->a_usar ?> </span>
       </h2>
       <input type="hidden" name="limite" value="<?=$_SESSION['invitadillo']->a_usar?>">
       <input type="hidden" name="nombre" value="<?=$_SESSION['invitadillo']->nombre?>">
       

       <div class="lacena">
        
       </div>
       <div class="comida-option">
       
       <label for="carne">Carne:</label>
       <select name="carne" id="carnecant"> 
       <?php 
         for($i=0; $i<= $_SESSION['invitadillo']->a_usar; $i++){                     
       ?>
       <option value="<?=$i?>"><?=$i?></option>
       <?php
         }
       ?>  
       </select>
       </div>
       
       
    
       
       <div class="comida-option">
       
       <label for="pollo">Pollo:</label>
       <select name="pollo" id="pollocant">
       <?php 
         for($i=0; $i<= $_SESSION['invitadillo']->a_usar; $i++){                     
       ?>
       <option value="<?=$i?>"><?=$i?></option>
       <?php
         }
       ?>  
       </select>
       </div>
       
       
       <div class="botones" style="display: flex; align-items: center; justify-content: center; ">
        <button type="submit" class="btn">Enviar</button>
   </div>
     </form>

      </div>
   
     

     
  
  
    </section>
  <?php elseif(isset($_SESSION['fin']) && $_SESSION['respuesta']=="si" && $_SESSION["plato"]==true && is_null($_SESSION['laid_final']->elreset) || $_SESSION['respuesta']==1):  ?>
        <div class="asistencia-confirm">
            <h2>Gracias por su confirmación</h2>
          </div>



        <div class="resumen">

        <div class="resumen-invitacion" style="text-aling: left;">
            <h2>Mesa asignada: n° <span> <?=$_SESSION['laid_final']->mesa ?> </span> </h2>
          </div>
          

          

          <div class="resumen-invitacion">
            <h2>Persona(s) permitida(s): <span> <?=$_SESSION['laid_final']->a_usar ?> </span></h2>
          </div>

          <div class="resumen-invitacion">
            <h2>Su cena de carne es: <span> <?=$_SESSION['laid_final']->carne ?> Plato(s)</span> </h2>
          </div>

          <div class="resumen-invitacion">
            <h2>Su cena de pollo es: <span> <?=$_SESSION['laid_final']->pollo ?> Plato(s)</span> </h2>
          </div>
        </div>

        <div class="resumen-invitacion" style="display: flex; align-items: center; justify-content: center; flex-direction: column;">

        <form action="<?=url_base?>Invitacion/elreset" method="post">
          <input type="hidden" name="nombre" value="<?=$_SESSION['laid_final']->nombre?>">
          <button type="submit" class="btn">¿Desea cambiar su respuesta? </button>
        </form>
        
        <p style="color: var(--secundario);">Solo podrá hacelo 1 vez más</p>
        </div>
        </div>

    <?php elseif(isset($_SESSION['fin']) && $_SESSION['respuesta']=="si" && $_SESSION["plato"]==true && is_null($_SESSION['laid_final']->elreset)==false || $_SESSION['respuesta']==1):?>
        <div class="asistencia-confirm">
            <h2>Gracias por su confirmación</h2>
          </div>



        <div class="resumen">
        <!-- 
        <div class="resumen-invitacion" style="text-aling: left;">
            <h2>Su Mesa asignada es: n° <span> <?=$_SESSION['laid_final']->mesa ?> </span> </h2>
          </div>
          
          -->
          

          <div class="resumen-invitacion">
            <h2>Persona(s) permitida(s): <span> <?=$_SESSION['laid_final']->a_usar ?> </span></h2>
          </div>

          <div class="resumen-invitacion">
            <h2>Su cena de carne es: <span> <?=$_SESSION['laid_final']->carne ?> Plato(s)</span> </h2>
          </div>

          <div class="resumen-invitacion">
            <h2>Su cena de pollo es: <span> <?=$_SESSION['laid_final']->pollo ?> Plato(s)</span> </h2>
          </div>
        </div>

        <div class="resumen-invitacion" style="display: flex; align-items: center; justify-content: center; flex-direction: column;">
        
        <p style="color: var(--secundario);">Ya no puede cambiar su respuesta</p>
        </div>
        </div>
    <?php elseif( $_SESSION['respuesta'] ==2):?>
        <div class="asistencia-confirm">
            <h2>Gracias por su confirmación</h2>
          </div>
        </div>
   
  <?php endif; ?>

  

<!-- asisntencia ends -->

<br><br><br>





        <!-- iconos start -->
        <!-- iconos start -->

        <section class="icons">


<div class="icon-container">

  <div class="icon-tarjet" id="tarjeta-vestimenta">
    <div class="icon-tarjet-content">
      <div class="tarjet-content-img">
        <img src="<?=url_base?>assets/img/iconos/icon-vestimenta.png" alt="">
      </div>
      <div class="tarjet-content-text">
        <h2>Vestimenta</h2>
      </div>
    </div>
  </div>
  
  <div class="icon-tarjet" id="tarjeta-galeria">
  
    <div class="icon-tarjet-content">
      <div class="tarjet-content-img">
        <img src="<?=url_base?>assets/img/iconos/icon-galeria.png" alt="">
      </div>
      <div class="tarjet-content-text">
        <h2>Galería</h2>
      </div>
    </div>
  </div>
  
  <div class="icon-tarjet" id="tarjeta-regalos">
    <div class="icon-tarjet-content">
      <div class="tarjet-content-img">
        <img src="<?=url_base?>assets/img/iconos/icon-regalo.png" alt="">
      </div>
      <div class="tarjet-content-text">
        <h2>Regalos</h2>
      </div>
    </div>
  </div>
  
  <div class="icon-tarjet" id="tarjeta-mensaje">
    <div class="icon-tarjet-content">
      <div class="tarjet-content-img">
        <img src="<?=url_base?>assets/img/iconos/icon-mensaje.png" alt="">
      </div>
      <div class="tarjet-content-text">
        <h2>Mensajes</h2>
      </div>
    </div>
  </div>
  


</div>


</section>


        <!-- icons ends -->


<!-- contenido oculto  -->
<section class="contenido-oculto">

  <!-- tarjeta vestimenta -->
  <div class="popup tart-vestimenta" id="popup-vestimenta" style="display:none;">

    <div class="vestimenta-content">
      
      <div class="vestimenta-title">
        <h1>  Código de vestimenta </h1>
      </div>
      <div class="vestimenta-text">

      <img src="<?=url_base?>assets/img/iconos/blacktie.png">

      </div>
      
      <div class="separador"></div>
      
    </div>
    

  </div>

  <!-- tarjeta galeria -->
  <div class="popup tart-galeria" id="popup-galeria" style="display:none;">
    
  <div class="galeria">

    <div class="container galeria">

      <div class="img-container">
        <img src="<?=url_base?>assets/img/sesion/sesion (1).png" alt="" class="main_img">
      </div>


      <div class="thumbnail_container">
        <img src="<?=url_base?>assets/img/sesion/sesion (1).png" alt="" class="thumbnail active">
        <img src="<?=url_base?>assets/img/sesion/sesion (14).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (3).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (13).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (5).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (6).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (12).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (9).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (10).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (11).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (7).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (4).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (2).png" alt="" class="thumbnail">
        <img src="<?=url_base?>assets/img/sesion/sesion (15).png" alt="" class="thumbnail">
        
      </div>
    </div>

    </div>
    <script>
  const main_img = document.querySelector('.main_img')
  const thumbnail  = document.querySelectorAll('.thumbnail')


  thumbnail.forEach(thumb => (
    thumb.addEventListener('click', function(){
      const active = document.querySelector('.active')
      active.classList.remove('active')
      this.classList.add('active')
      main_img.src = this.src
    })
  ))

</script>

  </div>
 
  <!-- tarjeta regalos -->
  <div class="popup tart-regalos" id="popup-regalos" style="display:none;">
    
    <div class="regalos-content">
      
      <div class="regalos-title">
        <h1>  Regalos </h1>
      </div>
      <div class="regalos-text">
        <h2>“El mejor regalo para este día especial es su compañía, pero si desean obsequiarnos algo más, nos gustaría que nos ayudarán en nuestro deseo de ahorrar”.</h2>

        <h2> Muestras de cariño de sobre.</h2>
      <!--  <a href="#" class="btn">Pague aqui</a> --> 
      </div>
      
      <div class="separador"></div>
      
    </div>

  </div>
  
 <!-- tarjeta mensaje -->
 <div style="margin-bottom: 4rem;" class="popup tart-mensaje" id="popup-mensaje" style="display:none;">
   

    <div class="escribir-mensaje">

      <div class="bandeja-title">
        <h2>Envíanos tus mejores deseos</h2>
      </div>
     

      <form action="<?=url_base?>Invitacion/insertar_mensaje" method="post">

        <div class="bandeja">
        <input type="hidden" name="elid" value="<?=$_SESSION['laIdentidad']->id?>">
          <textarea id="myTextarea" maxlength="200" oninput="updateCount()" name="mensaje"></textarea>
          <p><span id="count">0</span> / 200 </p>
        </div>

        <div class="botones">
        <button type="submit" class="btn">Enviar</button>
      </div>
      </form>

      

    </div>

  </div>
  
</section>


  <!-- mensajes -->

<section class="mensajes-novios">
  
 
  
<div class="testimonial mySwiper">
    <div class="testi-content swiper-wrapper">
      
        <?php 
          require_once "models/Invitados.php";
          $invitados = new Invitados();

          $resultado = $invitados->mostrar_invitados();
          while($mostrar=mysqli_fetch_array($resultado)){

            if($mostrar['mensaje']!=null){     
        ?>
        <!-- EL mensajes -->
        <div class="slide swiper-slide">
         

          <div class="slide-content">
            <p id="comentario">
            <?= $mostrar['mensaje']?>
              
            </p>
            <i class="bx bxs-quote-alt-left"></i>
    
            <div class="testi-detalles">
            
              <span class="nombre"><?= $mostrar['nombre']?></span>
              <span class="apellido"><?= $mostrar['apellidos']?></span>


            </div>
          </div>
          


        </div>
        <!-- EL mensajes -->
        <?php }?>
      <?php }?>
      
      


    </div>
    <div class="swiper-pagination"></div>
  </div>


 
</section>



  <!-- mensajes -->



    <div class="asistencia-confirm">
       <a href="https://manciaporrasds.com/" style="text-decoration: none;"><h2>Cerrar sesión</h2></a>
    </div>
<!-- flor -->
<div class="florcita">
  <img src="<?=url_base?>assets/img/iconos/flores.png" alt=""> <br><br><br><br>
</div>
<!-- marco -->
<div id="marco"></div>
<!-- cancion -->
<audio id="audio" src="<?=url_base?>assets/img/cancion/cancion-corta.mp3"></audio>
<div id="playButton" class="play-button"><i class="fas fa-play"></i></div>
	
</main>

<script src="https://cdn.jsdelivr.net/npm/swiper@9.1.1/swiper-bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?=url_base?>assets/js/script.js"></script> 


</body>
</html>