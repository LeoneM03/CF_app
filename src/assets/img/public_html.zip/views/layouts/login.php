<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preload" href="<?=url_base?>assets/css/style.css" as="style">
    <link rel="shortcut icon" href="<?=url_base?>assets/img/monograma-EA.png" />
    <link rel="stylesheet" href="<?=url_base?>assets/css/style.css">
    <SCRIPT LANGUAGE="JavaScript">
          history.forward()
    </SCRIPT>
    <title>¡Nos Casamos!</title>
</head>
 <!-- coloque una clase al body por la razón que vamos a manejar un css unificado para evitar el bajo rendimiento al tener mas de 1 css entonces para darle ajustes a una pagina propia pues la manejaremos asi -->
 <body class="login">
 

  <main>

 
    <div class="box">
      <!-- este solo es el cuadro blanco deja de mamar tanto con los comentarios putita Bv -->
      <div class="inner-box">
        
    <!-- esta zona controla lo que pasa en el formulario -->
        <div class="forms-wrap">
         
          <form action="<?=url_base?>Login/login" autocomplete="off" class="sign-in-form" method="post">
            <!-- es donde esta el logo, fijate que no se por que no se pudo alinear al centro de todo :v7 osea se que se hace su propio container pero esta al inicio pues deberia poder alinearce conforme a lo demas :v7 jummm luego lo vere a detalle -->
            <div class="logo">
              <img src="<?=url_base?>assets/img/monograma-EA.png" alt="AElogo" />
            </div>
          
            <!-- este es el header del formulario-->
            <div class="heading" style="text-align: center;">
              <h2 style="font-size: 1.8rem;" >Acompáñanos a nuestra boda</h2>
              <h6>deseamos que seas parte de este día especial</h6>
            </div>
          
            <!-- esta parte guarda los items y inputs del formulario -->
            <div class="actual-form">
          
              <div class="telefono-form">
          
                <!-- casilla de formulario -->
                <div class="input-wrap">
                  <select class="input-field" name="pais" required>
                    <option value="">--Seleccione un país--</option>
                    <option value="us">Estados Unidos (+1)</option>
                    <option value="sv">El Salvador (+503)</option>
                     <option value="guat">Guatemala (+502)</option>
                    <option value="mx">México (+52)</option>
                    <option value="es">España (+34)</option>
                      <option value="ca">Canada (+1)</option>
                       
                  </select>
                
                </div>
          
                <!-- casilla de formulario -->
                <div class="input-wrap">
                  <input
                    type="tel"
                    class="input-field"
                    minlength="3"
                    maxlength="15"
                    autocomplete="off"
                    name="telefono"
                    required
                  />
                  <label>Numero de teléfono</label>
                </div>
          
              </div>
          
              <!-- enserio? logo ahi dice btn osea boton :v thing mark thing -->
              <input type="submit" value="Iniciar" class="sign-btn" />
          
            </div>
          </form>
        </div>

        <!-- carrusel -->
        <div class="carousel">
          <!-- el container de las imagenes la clase show hace que te muestre esa imagen en especifico al inicio -->
          <div class="images-wrapper">
            <img src="<?=url_base?>assets/img/login/login (1).jpg" class="image img-1 show" alt="" />
            <img src="<?=url_base?>assets/img/login/login (2).jpg" class="image img-2" alt="" />
            <img src="<?=url_base?>assets/img/login/login (3).jpg" class="image img-3" alt="" />
            <img src="<?=url_base?>assets/img/login/login (4).jpg" class="image img-4" alt="" />
          </div>

          <!-- el container para los textos, si queres agregar mas frases se agrega un h2 al igual que una imagen en la parte anterior-->
          <div class="text-slider">
            <div class="text-wrap">
              <div class="text-group">
                <h2>El símbolo de nuestro amor</h2>
                <h2>...Iniciaremos nuestro viaje juntos</h2>
                <h2>y no podemos esperar a donde nos lleva</h2>
                <h2></h2>
              </div>
            </div>

            <!-- son los circulitos que aparecen como controles del carrusel, el active es la cosita que se alarga cuando esta en ese item xd -->
            <div class="bullets">
              <span class="active" data-value="1"></span>
              <span data-value="2"></span>
              <span data-value="3"></span>
              <span data-value="4"></span>
            </div>
          </div>
        </div>
        <!-- carrusel -->

      </div>

      
    </div>
  </main>
<?php if(isset($_SESSION['fallo_credencial'])): ?>   
        <script type="text/javascript">
          alert("Error en Numero o País");
        </script>
      <?php endif; ?> 
  <!-- Javascript file -->

  <script src="<?=url_base?>assets/js/login.js"></script>
</body>
</html>
