<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preload" href="CSS/admin.css" as="style">
    <link rel="shortcut icon" href="<?=url_base?>assets/img/monograma-EA.png" />
    <link rel="stylesheet" href="<?=url_base?>assets/CSS/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Home</title>
</head>


<body class="admin">

    <header>
        <nav>
          <h1>Para la patrona</h1>
          <ul>
            <h2>
                Bienvenida <span> Alejandra Porras</span> 
            </h2>
            <li>
              <a href="index.html"> Cerrar Sesión </a>
            </li>
          </ul>
        </nav>
      </header>

      

    <section class="dashasist">

        <h1>
            Listado de invitados
        </h1>
        <table>
          <thead>
            <tr>
              <th>Código area</th>
              <th>Teléfono</th>
              <th>Nombre</th>
              <th>Asientos</th>
              <th>Asientos a usar</th>
              <th>Mesa</th>
              <th>Confirmación</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
          <?php 
              require_once "models/Invitados.php";
              $invitados = new Invitados();

              $resultado = $invitados->mostrar_invitados();
              while($mostrar=mysqli_fetch_array($resultado)){

            ?>
            <tr>

              <?php 
                $elpais = $mostrar['pais'];
                switch($elpais){
                    case "us":
                        echo '<td>+1</td>';
                    break;

                    case "sv":
                        echo '<td>+503</td>';
                    break;

                    case "mx":
                        echo '<td>+52</td>';
                    break;

                    case "es":
                        echo '<td>+54</td>';
                    break;   

                }
              
              ?>
              <td><?php echo $mostrar['telefono'] ?></td>
              <td><?php echo $mostrar['nombre'] ?></td>
              <td><?php echo $mostrar['asientos'] ?></td>

              <?php if($mostrar['a_usar']!=null):?>
                <td><?php echo $mostrar['a_usar'] ?></td>
              <?php else: ?>
                <td>Sin confirmar</td>
              <?php endif; ?>

              <td><?php echo $mostrar['mesa'] ?></td>

              <?php if($mostrar['asistencia'] == 1):?>
                <td>SI</td>
              <?php elseif($mostrar['asistencia'] == 2): ?>
                <td>no</td>
              <?php else: ?>
                <td>Sin confirmar</td>
              <?php endif; ?>

              <td class="actions">
                <button class="edit">Editar</button>
                <button class="delete">Borrar</button>
              </td>
            </tr>
            <?php
              }
            ?>
          </tbody>
        </table>
          <div class="boton">
            <input type="submit" value="Imprimir listado" class="btn" />
          </div>

    </section>


    <section class="invitados-agree">

        <div class="formulario">
            <h1>
                Agregar invitados
            </h1>
    
                <form class="user" action="<?=url_base?>Portal/registrar" method="post">
                    <div class="actual-form">
                        

                        <!-- casilla de formulario -->
                        <div class="input-wrap">
                          
                            <select class="input-field" name="pais" required>
                                <option value="">--Código de area--</option>
                                <option value="us">Estados Unidos (+1)</option>
                                <option value="sv">El Salvador (+503)</option>
                                <option value="mx">México (+52)</option>
                                <option value="es">España (+34)</option>
                            </select>
                          
                        </div>
                       <!-- casilla de formulario -->
                       <div class="input-wrap">
                        <input
                          type="number"
                          minlength="4"
                          class="input-field"
                          autocomplete="off"
                          name="telefono"
                          placeholder="Telefono"
                          required
                        />
                        
                      </div>
                        <!-- casilla de formulario -->
                        <div class="input-wrap">
                          <input
                            type="text"
                            minlength="4"
                            class="input-field"
                            autocomplete="off"
                            name="nombre"
                            placeholder="Nombre Invitado"
                            required
                          />
                        
                        </div>
                          <!-- casilla de formulario -->
                          <div class="input-wrap">
                            <input
                              type="number"
                              minlength="1"
                              class="input-field"
                              autocomplete="off"
                              placeholder="Asientos disponibles"
                              name="asientos"
                              required
                            />
                           
                          </div>
                            <!-- casilla de formulario -->
                        
                        <div class="input-wrap">
                            <input
                              type="number"
                              minlength="4"
                              class="input-field"
                              autocomplete="off"
                              name="mesa"
                              placeholder="Mesa Asignar"
                              required
                            />
                           
                            
                          </div>
                            <!-- casilla de formulario -->
        
                      </div>
    
                       <!-- enserio? lee ahi dice btn osea boton :v thing mark thing -->
                       <div class="boton">
                        <input type="submit" value="Agregar" class="btn" />
                      </div>
    
                </form>
        </div>


        

    </section>
        <script src="<?=url_base?>assets/JS/script.js"></script>   
</body>


</html>